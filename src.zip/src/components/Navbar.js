import React from 'react'
import PropTypes from 'prop-types'
import  img1 from './images/EVENT.jpg'; 

export default function Navbar(props) {
   
  
  return (
   
     <nav className="navbar navbar-expand-lg navbar-light bg-light">
  <a className="navbar-brand" href="/">{props.title}</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarSupportedContent">
    <ul className="navbar-nav mr-auto">
      <li className="nav-item active">
        <a className="nav-link" href="/">Home <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="/">Venue</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="/">Caterers</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="/">Decorators</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="/"> About   </a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="/">Contact us</a>
      </li>
      
    </ul>
    <form className="form-inline my-2 my-lg-0">
      <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"/>
      <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
  <img src={img1} alt=" "/>
</nav>

   
  );
  

}
Navbar.propTypes = {title:PropTypes.string.isRequired,
               aboutText:PropTypes.string.isRequired
}

Navbar.defaultProps = {title:'set title here',
aboutText:'About text here'
}



<section className="photographers-section">
        
          <h2>Get Professional Photographers</h2>
          <p>Capture your every memory to make it memorable</p>
          <div className="photographers-item">
            <div style={{
              width:"500px",
              height:"500px",
              backgroundImage: 'url(${photography})',
              backgroundSize: "contain",
              backgroundRepeat:"no-repeat"
            }}>
              <img src="./images/Rectangle 12.png" alt="Photographers" />

            </div>
         
            <p>Photographers</p>
          </div>
        </section>
  
