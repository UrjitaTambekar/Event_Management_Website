import React from 'react'
import "./Home.css";


export default function Home() {
   
  
    return (
      <div className="App">
        <header className="header">
          <h1>ShubhEvent</h1>
          <nav>
            <ul>
              <li>Home</li>
              <li>Venues</li>
              <li>Catering</li>
              <li>Decorations</li>
              <li>About</li>
              <li>Contact</li>
            </ul>
          </nav>
          <button className="login-btn">Login</button>
          <button className="signup-btn">Signup</button>
        </header>
  
        <section className="hero-section">
          <img src="./images/Rectangle 7.png" alt="Wedding celebration" />
        </section>
  
        <section className="category-section">
          <h2>Browse Hall By Category</h2>
          <div className="category-grid">
            <div className="category-item">
              <img src="./images/wedding-hall 1.png"alt="Banquet Halls" />
              <p>Banquet Halls</p>
            </div>
            <div className="category-item">
              <img src="./images/conference 1.png"alt="Conference Halls" />
              <p>Conference Halls</p>
            </div>
            <div className="category-item">
              <img src="./images/Fairmont-Copley-Grand-Ballroom-694x390 1.png" alt="Ballrooms" />
              <p>Ballrooms</p>
            </div>
            <div className="category-item">
              <img src="./images/outdoor 1.png" alt="Clubhouses" />
              <p>Clubhouses</p>
            </div>
          </div>
        </section>
  
        <section className="catering-section">
          <h2>Browse Catering Service</h2>
          <div className="catering-grid">
            <div className="catering-item">
              <img src="./images/Group 529.png" alt="Wedding Catering" />
              <p>Wedding Catering</p>
            </div>
            <div className="catering-item">
              <img src="./images/Group 530.png"alt="Corporate Catering" />
              <p>Corporate Catering</p>
            </div>
            <div className="catering-item">
              <img src="./images/Group 627.png" alt="Buffet Catering" />
              <p>Buffet Catering</p>
            </div>
            <div className="catering-item">
              <img src="./images/Group 628.png" alt="Daily Tiffins" />
              <p>Daily Tiffins</p>
            </div>
          </div>
        </section>
  
        <section className="photographers-section">
          <div className="photographers-item">
          <header className="caterers-header">
      <img src="./images/Rectangle 12.png" alt="Caterers Banner" className="banner-image" />
      <h2>Get Professional Photographers</h2>
          <p>Capture your every memory to make it memorable</p>
    </header>
              

            
         
            <p>Photographers</p>
          </div>
        </section>
  
        <section className="other-services-section">
          <h2>Other Services</h2>
          <div className="services-grid">
            <div className="service-item">
              <img src="./images/Group 625.png" alt="Event Decorations" />
              <p>Event Decorations</p>
            </div>
            <div className="service-item">
              <img src="./images/Group 626.png"alt="Event Managers" />
              <p>Event Managers</p>
            </div>
            <div className="service-item">
              <img src="./images/Group 531.png" alt="Dress Designers" />
              <p>Dress Designers</p>
            </div>
            <div className="service-item">
              <img src="./images/Group 532.png" alt="Cakes" />
              <p>Cakes</p>
            </div>
          </div>
        </section>
  
        <section className="reviews-section">
          <h2>Reviews</h2>
          <div className="review-carousel">
            <div className="review-item">
              <p>LOREM IPSUM - Customer feedback goes here.</p>
            </div>
            <div className="carousel-controls">
              <span className="prev">&#10094;</span>
              <span className="next">&#10095;</span>
            </div>
          </div>
        </section>
  
        <footer className="footer">
          <div className="footer-logo">Footer</div>
          <div className="footer-content">
            <div className="footer-section">
              <h4>Company Logo</h4>
              <p>Some description about the company.</p>
            </div>
            <div className="footer-section">
              <h4>Links</h4>
              <ul>
                <li>Home</li>
                <li>About</li>
                <li>Services</li>
                <li>Contact</li>
              </ul>
            </div>
            <div className="footer-section">
              <h4>Contact Us</h4>
              <p>+123456789</p>
              <p>info@example.com</p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>© 2024 ShubhEvent. All rights reserved.</p>
          </div>
        </footer>
      </div>
    );
  }
  
 