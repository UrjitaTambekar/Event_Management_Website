import React from 'react'
import "./Venue.css";


export default function Caterers() {



  const venuesData = [
    {
      name: 'Elegant Banquet Hall',
      location: 'New Delhi, India',
      price: '10000rs.',
      rating: 5,
      reviews: 22,
      image: 'path-to-venue-image2.jpg'
    },
    {
      name: 'Royal Palace Venue',
      location: 'Mumbai, India',
      price: '12000rs.',
      rating: 4.8,
      reviews: 30,
      image: 'path-to-venue-image2.jpg'
    },
    {
      name: 'Royal Palace Venue',
      location: 'Mumbai, India',
      price: '12000rs.',
      rating: 4.8,
      reviews: 30,
      image: 'path-to-venue-image2.jpg'
    },
    {
      name: 'Royal Palace Venue',
      location: 'Mumbai, India',
      price: '12000rs.',
      rating: 4.8,
      reviews: 30,
      image: 'path-to-venue-image2.jpg'
    },
    {
      name: 'Royal Palace Venue',
      location: 'Mumbai, India',
      price: '12000rs.',
      rating: 4.8,
      reviews: 30,
      image: 'path-to-venue-image2.jpg'
    },
    {
      name: 'Royal Palace Venue',
      location: 'Mumbai, India',
      price: '12000rs.',
      rating: 4.8,
      reviews: 30,
      image: 'path-to-venue-image2.jpg'
    },{
      name: 'Royal Palace Venue',
      location: 'Mumbai, India',
      price: '12000rs.',
      rating: 4.8,
      reviews: 30,
      image: 'path-to-venue-image2.jpg'
    },
  ];

  return (
    <div className="venues">
      <header className="venues-header">
        <img src="./images/Rectangle 7 (1).png" alt="Venue Banner" className="banner-image" />
        <h1>Our Venues</h1>
      </header>
      <div className="venues-filters">
        <select><option>Select Category</option></select>
        <select><option>Select Location</option></select>
        <button>Search</button>
      </div>
      <div className="advanced-filters">
        <select><option>No. of Guests</option></select>
        <select><option>Venue Type</option></select>
        <select><option>Space Preference</option></select>
        <select><option>Rating</option></select>
        <button>Search</button>
      </div>
      <div className="venues-list">
        {venuesData.map((venue, index) => (
          <div className="venue-card" key={index}>
            <img src={venue.image} alt={venue.name} className="venue-image" />
            <div className="venue-info">
              <h2>{venue.name}</h2>
              <p>{venue.location}</p>
              <p>Rating: ★★★★★ {venue.rating} ({venue.reviews})</p>
              <p>Price: {venue.price}, Per Day</p>
              <button className="availability-btn">Check Availability</button>
              <button className="info-btn">View More Info</button>
              <button className="book-btn">Book Now</button>
            </div>
          </div>
        ))}
      </div>
      <footer className="footer">
          <div className="footer-logo">Footer</div>
          <div className="footer-content">
            <div className="footer-section">
              <h4>Company Logo</h4>
              <p>Some description about the company.</p>
            </div>
            <div className="footer-section">
              <h4>Links</h4>
              <ul>
                <li>Home</li>
                <li>About</li>
                <li>Services</li>
                <li>Contact</li>
              </ul>
            </div>
            <div className="footer-section">
              <h4>Contact Us</h4>
              <p>+123456789</p>
              <p>info@example.com</p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>© 2024 ShubhEvent. All rights reserved.</p>
          </div>
        </footer>
    </div>
    
  );
}