import React from 'react'
import "./Caterers.css";

export default function Caterers() {
const caterersData = [
  {
    name: 'Gourmet Catering Service',
    location: 'Pune, India',
    price: '10000rs.',
    rating: 5,
    reviews: 22,
    image: 'path-to-caterer-image1.jpg'
  },
  {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  },
  {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  }, {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  }, {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  }, {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  }, {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  }, {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  }, {
    name: 'Royal Feast Caterers',
    location: 'Chennai, India',
    price: '12000rs.',
    rating: 4.8,
    reviews: 35,
    image: 'path-to-caterer-image2.jpg'
  },
];

return (
  <div className="caterers">
    <header className="caterers-header">
      <img src="./images/Rectangle 7 (2).png"alt="Caterers Banner" className="banner-image" />
      <h1>Our Caterers</h1>
    </header>
    <div className="caterers-filters">
      <select><option>Select Category</option></select>
      <select><option>Select Location</option></select>
      <button>Search</button>
    </div>
    <div className="advanced-filters">
      <select><option>No. of Guests</option></select>
      <select><option>Food Type</option></select>
      <select><option>Service Type</option></select>
      <select><option>Rating</option></select>
      <button>Search</button>
    </div>
    <div className="caterers-list">
      {caterersData.map((caterer, index) => (
        <div className="caterer-card" key={index}>
          <img src={caterer.image} alt={caterer.name} className="caterer-image" />
          <div className="caterer-info">
            <h2>{caterer.name}</h2>
            <p>{caterer.location}</p>
            <p>Rating: ★★★★★ {caterer.rating} ({caterer.reviews})</p>
            <p>Price: {caterer.price} Per Day</p>
            <button className="availability-btn">Check Availability</button>
            <button className="info-btn">View More Info</button>
            <button className="book-btn">Book Now</button>
          </div>
        </div>
      ))}
    </div>
    <footer className="footer">
          <div className="footer-logo">Footer</div>
          <div className="footer-content">
            <div className="footer-section">
              <h4>Company Logo</h4>
              <p>Some description about the company.</p>
            </div>
            <div className="footer-section">
              <h4>Links</h4>
              <ul>
                <li>Home</li>
                <li>About</li>
                <li>Services</li>
                <li>Contact</li>
              </ul>
            </div>
            <div className="footer-section">
              <h4>Contact Us</h4>
              <p>+123456789</p>
              <p>info@example.com</p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>© 2024 ShubhEvent. All rights reserved.</p>
          </div>
        </footer>
  </div>
);
}
