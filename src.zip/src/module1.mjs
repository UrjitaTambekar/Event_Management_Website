import ui from './module2.mjs'
console.log(ui);