const a= "harry";
const b= "abc";
const c= "hgf";
const d= "xyz";

export default b;

