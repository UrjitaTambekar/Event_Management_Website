import './App.css';
import Home from './components/Home';
import Caterers from './components/Caterers';
import Venue from './components/Venue';


function App() {
  
  return (
    <>
    
 {/*<Navbar title="TextUtils" aboutText="About textutisl"/>*/}
  { /*<Navbar/>*/}
  <Home />
  <Caterers />
  <Venue />
  
    </>
    
  );
  

}

export default App;